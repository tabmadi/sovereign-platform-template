{{/* ~=~=~ Exposed Ports — trimmed to Prometheus metrics + OTLP only ~=~=~ */}}
{{/* This template's Service ports were pruned from the upstream chart: jaeger,   */}}
{{/* zipkin, opencensus and the OTLP-legacy sockets are not used (the OTel        */}}
{{/* collector ships traces to tempo over OTLP). Keep in sync with the receivers  */}}
{{/* block in values.yaml.                                                        */}}

{{- define "tempo.udp"}}
{{- end }}

{{- define "tempo.tcp"}}
- name: tempo-prom-metrics
  port: 3200
  protocol: TCP
  targetPort: 3200
{{- $endpoint := .Values.tempo.receivers.otlp.protocols.grpc }}
{{- with $endpoint.endpoint }}
{{- $port := regexSplit ":" . -1 | last }}
- name: grpc-tempo-otlp
  port: {{ $port }}
  protocol: TCP
  targetPort: 4317
{{- end }}
{{- $endpoint := .Values.tempo.receivers.otlp.protocols.http }}
{{- with $endpoint.endpoint }}
{{- $port := regexSplit ":" . -1 | last }}
- name: tempo-otlp-http
  port: {{ $port }}
  protocol: TCP
  targetPort: 4318
{{- end }}
{{- end }}
